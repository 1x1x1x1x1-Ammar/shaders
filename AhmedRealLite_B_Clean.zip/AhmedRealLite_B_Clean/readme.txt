AhmedRealLite B (Clean Realistic) - Shadows OFF
Target: Low-end GPUs (AMD HD 7xxx / Intel HD)
Look: Clean realistic (SEUS-ish vibe) using:
- Filmic tonemap
- Distance haze/fog
- Very light bloom

Install:
Put the zip into .minecraft/shaderpacks/
Enable in Iris Shader Packs menu.

If you get low FPS:
- Reduce render distance to 6-8
- Turn clouds OFF
- Keep particles minimal
